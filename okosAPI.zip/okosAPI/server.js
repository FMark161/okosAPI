const express = require("express");

const app = express();
const PORT = 3000;

app.get("/api/time", (req, res) => {
  const now = new Date();
  const time = now.toTimeString().split(" ")[0];
  res.json({ time });
});

app.get("/api/date", (req, res) => {
  const today = new Date().toISOString().split("T")[0];
  res.json({ date: today });
});


app.get("/api/temp", async (req, res) => {
  try {
    const url = "https://api.open-meteo.com/v1/forecast?latitude=46.7681&longitude=17.2430&current_weather=true";
    const response = await fetch(url);
    const data = await response.json();
    
    const temp = data.current_weather.temperature;
    res.json({ location: "Keszthely", temperature: temp });
  } catch (error) {
    res.status(500).json({ error: "Nem sikerült lekérni az adatokat!" });
  }
});

const greetings = [
  "Jól vagyok!",
  "Nagyon jól vagyok!",
  "Remekül vagyok!",
  "Fantasztikusan érzem magam!",
  "Sose voltam jobban!",
  "Elég jól!",
  "Fáradtan.",
  "Lehetne jobb is, de nem panaszkodom.",
  "Csodásan érzem magam!",
  "Minden rendben van velem!"
];

let usedGreetings = new Set();

app.get("/api/greetings", (req, res) => {
  if (usedGreetings.size === greetings.length) {
    usedGreetings.clear();
  }

  const available = greetings.filter(g => !usedGreetings.has(g));
  const choice = available[Math.floor(Math.random() * available.length)];
  
  usedGreetings.add(choice);
  res.json({ greeting: choice });
});

app.listen(PORT, () => {
  console.log(`okosAPI fut a http://localhost:${PORT} címen`);
});
